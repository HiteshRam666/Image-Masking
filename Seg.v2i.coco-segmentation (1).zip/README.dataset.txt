# Seg > 2024-10-11 3:52am
https://universe.roboflow.com/hiteshram/seg-vskov

Provided by a Roboflow user
License: CC BY 4.0

